"""NanoPy Faucet - Testnet token distributor"""
__version__ = "1.0.0"
